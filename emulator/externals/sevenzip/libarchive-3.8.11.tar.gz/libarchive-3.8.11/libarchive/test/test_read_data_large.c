/*-
 * Copyright (c) 2003-2007 Tim Kientzle
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR(S) ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "test.h"

/*
 * Test read/write of a 10M block of data in a single operation.
 * Uses an in-memory archive with a single 10M entry.  Exercises
 * archive_read_data() to ensure it can handle large blocks like
 * this and also exercises archive_read_data_into_fd() (which
 * had a bug relating to this, fixed in Nov 2006).
 */

#if defined(_WIN32) && !defined(__CYGWIN__)
#define open _open
#define close _close
#define ftruncate _chsize
#endif

static char buff1[11000000];
static char buff2[10000000];
static char buff3[10000000];

DEFINE_TEST(test_read_data_large)
{
	struct archive_entry *ae;
	struct archive *a;
	char tmpfilename[] = "largefile";
	int tmpfilefd;
	FILE *f;
	size_t used;

	/* Create a new archive in memory. */
	assert((a = archive_write_new()) != NULL);
	assertA(0 == archive_write_set_format_ustar(a));
	assertA(0 == archive_write_add_filter_none(a));
	assertA(0 == archive_write_open_memory(a, buff1, sizeof(buff1), &used));

	/*
	 * Write a file (with random contents) to it.
	 */
	assert((ae = archive_entry_new()) != NULL);
	archive_entry_copy_pathname(ae, "file");
	archive_entry_set_mode(ae, S_IFREG | 0755);
	fill_with_pseudorandom_data(buff2, sizeof(buff2));
	archive_entry_set_size(ae, sizeof(buff2));
	assertA(0 == archive_write_header(a, ae));
	archive_entry_free(ae);
	assertA((int)sizeof(buff2) == archive_write_data(a, buff2, sizeof(buff2)));

	/* Close out the archive. */
	assertEqualIntA(a, ARCHIVE_OK, archive_write_close(a));
	assertEqualInt(ARCHIVE_OK, archive_write_free(a));

	/* Check that archive_read_data can handle 10*10^6 at a pop. */
	assert((a = archive_read_new()) != NULL);
	assertA(0 == archive_read_support_format_all(a));
	assertA(0 == archive_read_support_filter_all(a));
	assertA(0 == archive_read_open_memory(a, buff1, sizeof(buff1)));
	assertA(0 == archive_read_next_header(a, &ae));
	failure("Wrote 10MB, but didn't read the same amount");
	assertEqualIntA(a, sizeof(buff2),archive_read_data(a, buff3, sizeof(buff3)));
	failure("Read expected 10MB, but data read didn't match what was written");
	assertEqualMem(buff2, buff3, sizeof(buff3));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_close(a));
	assertEqualInt(ARCHIVE_OK, archive_read_free(a));

	/* Check archive_read_data_into_fd */
	assert((a = archive_read_new()) != NULL);
	assertA(0 == archive_read_support_format_all(a));
	assertA(0 == archive_read_support_filter_all(a));
	assertA(0 == archive_read_open_memory(a, buff1, sizeof(buff1)));
	assertA(0 == archive_read_next_header(a, &ae));
#if defined(__BORLANDC__)
	tmpfilefd = open(tmpfilename, O_WRONLY | O_CREAT | O_BINARY);
#else
	tmpfilefd = open(tmpfilename, O_WRONLY | O_CREAT | O_BINARY, 0777);
#endif
	assert(tmpfilefd != 0);
	assertEqualIntA(a, 0, archive_read_data_into_fd(a, tmpfilefd));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_close(a));
	assertEqualInt(ARCHIVE_OK, archive_read_free(a));
	close(tmpfilefd);

	f = fopen(tmpfilename, "rb");
	assert(f != NULL);
	assertEqualInt(sizeof(buff3), fread(buff3, 1, sizeof(buff3), f));
	fclose(f);
	assertEqualMem(buff2, buff3, sizeof(buff3));
}

#define	FILE_SIZE	0x90000		/* 576 KiB total logical size */

static char sparse_buff[0x10000];	/* Holds the (small) stored archive. */
static char sparse_data[FILE_SIZE];
static char sparse_expected[FILE_SIZE];

/*
 * Regression test for archive_read_data_into_fd() extracting a sparse
 * file that ends in a hole. For a sparse entry libarchive seeks the
 * destination descriptor forward to recreate holes. The trailing hole
 * is created from the EOF handling after the last data block.
 */
DEFINE_TEST(test_read_data_into_fd_sparse)
{
	struct archive *a;
	struct archive_entry *ae;
	size_t archive_size = 0;
	const char *skip_sparse_tests;
	int fd;

	skip_sparse_tests = getenv("SKIP_TEST_SPARSE");
	if (skip_sparse_tests != NULL) {
		skipping("Skipping sparse tests due to SKIP_TEST_SPARSE "
		"environment variable");
		return;
	}

	/*
	 * The logical file is all 'a', and the sparse map marks two data
	 * regions, everything else (including the tail) is a hole that
	 * must read back as zero. The last data region ends at 0x81000
	 * while the file size is 0x90000, so the file ends in a hole.
	 */
	memset(sparse_data, 'a', sizeof(sparse_data));
	memset(sparse_expected, 0, sizeof(sparse_expected));
	memset(sparse_expected + 0x10000, 'a', 0x1000);
	memset(sparse_expected + 0x80000, 'a', 0x1000);

	/* Create a sparse pax archive in memory. */
	assert((a = archive_write_new()) != NULL);
	assertEqualIntA(a, ARCHIVE_OK, archive_write_set_format_pax(a));
	assertEqualIntA(a, ARCHIVE_OK, archive_write_add_filter_none(a));
	assertEqualIntA(a, ARCHIVE_OK, archive_write_open_memory(a, sparse_buff,
	    sizeof(sparse_buff), &archive_size));

	assert((ae = archive_entry_new()) != NULL);
	archive_entry_copy_pathname(ae, "file");
	archive_entry_set_mode(ae, S_IFREG | 0644);
	archive_entry_set_size(ae, FILE_SIZE);
	archive_entry_sparse_add_entry(ae, 0x10000, 0x1000);
	archive_entry_sparse_add_entry(ae, 0x80000, 0x1000);
	assertEqualIntA(a, ARCHIVE_OK, archive_write_header(a, ae));
	archive_entry_free(ae);
	assertEqualIntA(a, FILE_SIZE,
	    archive_write_data(a, sparse_data, sizeof(sparse_data)));
	assertEqualIntA(a, ARCHIVE_OK, archive_write_close(a));
	assertEqualInt(ARCHIVE_OK, archive_write_free(a));

	/* Read it back and extract it into a real file descriptor. */
	assert((a = archive_read_new()) != NULL);
	assertEqualIntA(a, ARCHIVE_OK, archive_read_support_format_all(a));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_support_filter_all(a));
	assertEqualIntA(a, ARCHIVE_OK,
	    archive_read_open_memory(a, sparse_buff, archive_size));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_next_header(a, &ae));
	assertEqualInt(FILE_SIZE, archive_entry_size(ae));

	fd = open("file", O_WRONLY | O_CREAT | O_BINARY, 0644);
	assert(fd >= 0);

	assertEqualIntA(a, ARCHIVE_OK, archive_read_data_into_fd(a, fd));

	/*
	 * archive_read_data_into_fd() seeks over the trailing hole but, like
	 * a regular extraction, leaves the on-disk size short. Truncate up
	 * to the full size to realize the final hole, as a consumer does.
	 */
	assert(ftruncate(fd, FILE_SIZE) != -1);
	close(fd);

	assertEqualIntA(a, ARCHIVE_OK, archive_read_close(a));
	assertEqualInt(ARCHIVE_OK, archive_read_free(a));

	/*
	 * The reconstructed file must match byte for byte: data regions
	 * are 'a', every hole (including the trailing one) is zero.
	 */
	assertFileSize("file", FILE_SIZE);
	assertFileContents(sparse_expected, FILE_SIZE, "file");
}

/*
 * Extracting into a non-empty file opened with O_APPEND, as in
 * "bsdtar -xO >> file", must append plain and sparse entries.
 */
DEFINE_TEST(test_read_data_into_fd_append)
{
	static char buff[32768];
	static char hole_data[0x3000];
	static char expected[7 + sizeof(hole_data) + 6];
	struct archive *a;
	struct archive_entry *ae;
	size_t archive_size = 0, expected_size;
	int fd;

	assertMakeFile("append", 0644, "header\n");

	/* Entries one and two are plain, "sparse" is a hole, data, a hole. */
	memset(hole_data, 'a', sizeof(hole_data));
	assert((a = archive_write_new()) != NULL);
	assertEqualIntA(a, ARCHIVE_OK, archive_write_set_format_pax(a));
	assertEqualIntA(a, ARCHIVE_OK, archive_write_add_filter_none(a));
	assertEqualIntA(a, ARCHIVE_OK,
	    archive_write_open_memory(a, buff, sizeof(buff), &archive_size));
	assert((ae = archive_entry_new()) != NULL);
	archive_entry_copy_pathname(ae, "sparse");
	archive_entry_set_mode(ae, S_IFREG | 0644);
	archive_entry_set_size(ae, sizeof(hole_data));
	archive_entry_sparse_add_entry(ae, 0x1000, 0x1000);
	assertEqualIntA(a, ARCHIVE_OK, archive_write_header(a, ae));
	assertEqualIntA(a, (int)sizeof(hole_data),
	    archive_write_data(a, hole_data, sizeof(hole_data)));
	archive_entry_free(ae);
	assert((ae = archive_entry_new()) != NULL);
	archive_entry_copy_pathname(ae, "one");
	archive_entry_set_mode(ae, S_IFREG | 0644);
	archive_entry_set_size(ae, 3);
	assertEqualIntA(a, ARCHIVE_OK, archive_write_header(a, ae));
	assertEqualIntA(a, 3, archive_write_data(a, "one", 3));
	archive_entry_free(ae);
	assert((ae = archive_entry_new()) != NULL);
	archive_entry_copy_pathname(ae, "two");
	archive_entry_set_mode(ae, S_IFREG | 0644);
	archive_entry_set_size(ae, 3);
	assertEqualIntA(a, ARCHIVE_OK, archive_write_header(a, ae));
	assertEqualIntA(a, 3, archive_write_data(a, "two", 3));
	archive_entry_free(ae);
	assertEqualIntA(a, ARCHIVE_OK, archive_write_close(a));
	assertEqualInt(ARCHIVE_OK, archive_write_free(a));

	assert((a = archive_read_new()) != NULL);
	assertEqualIntA(a, ARCHIVE_OK, archive_read_support_format_all(a));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_support_filter_all(a));
	assertEqualIntA(a, ARCHIVE_OK,
	    archive_read_open_memory(a, buff, archive_size));

	fd = open("append", O_WRONLY | O_APPEND | O_BINARY);
	assert(fd >= 0);
	assertEqualIntA(a, ARCHIVE_OK, archive_read_next_header(a, &ae));
	assertEqualString("sparse", archive_entry_pathname(ae));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_data_into_fd(a, fd));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_next_header(a, &ae));
	assertEqualString("one", archive_entry_pathname(ae));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_data_into_fd(a, fd));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_next_header(a, &ae));
	assertEqualString("two", archive_entry_pathname(ae));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_data_into_fd(a, fd));
	close(fd);

	memset(expected, 0, sizeof(expected));
#if defined(_WIN32) && !defined(__CYGWIN__)
	/*
	 * The library writes with WriteFile(), which ignores O_APPEND, so
	 * the data starts at the beginning of the file. Skipped holes keep
	 * what was there.
	 */
	memcpy(expected, "header\n", 7);
	memset(expected + 0x1000, 'a', 0x1000);
	memcpy(expected + sizeof(hole_data), "onetwo", 6);
	expected_size = sizeof(hole_data) + 6;
#else
	memcpy(expected, "header\n", 7);
	memset(expected + 7 + 0x1000, 'a', 0x1000);
	memcpy(expected + 7 + sizeof(hole_data), "onetwo", 6);
	expected_size = 7 + sizeof(hole_data) + 6;
#endif
	assertEqualIntA(a, ARCHIVE_EOF, archive_read_next_header(a, &ae));
	assertEqualIntA(a, ARCHIVE_OK, archive_read_close(a));
	assertEqualInt(ARCHIVE_OK, archive_read_free(a));

	assertFileSize("append", (int)expected_size);
	assertFileContents(expected, (int)expected_size, "append");
}
