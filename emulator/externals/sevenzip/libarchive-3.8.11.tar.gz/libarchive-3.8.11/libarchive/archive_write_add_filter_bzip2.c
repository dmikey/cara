/*-
 * Copyright (c) 2003-2007 Tim Kientzle
 * Copyright (c) 2012 Michihiro NAKAJIMA
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR(S) ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "archive_platform.h"

#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif
#include <stdio.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_BZLIB_H
#include <bzlib.h>
#endif

#include "archive.h"
#include "archive_private.h"
#include "archive_write_private.h"

#if ARCHIVE_VERSION_NUMBER < 4000000
int
archive_write_set_compression_bzip2(struct archive *a)
{
	__archive_write_filters_free(a);
	return (archive_write_add_filter_bzip2(a));
}
#endif

struct bzip2 {
	int		 compression_level;
#if defined(HAVE_BZLIB_H) && defined(BZ_CONFIG_ERROR)
	bz_stream	 stream;
	char		*compressed;
	size_t		 compressed_buffer_size;
#else
	struct archive_write_program_data *pdata;
#endif
};

static int archive_compressor_bzip2_close(struct archive_write_filter *);
static int archive_compressor_bzip2_free(struct archive_write_filter *);
static int archive_compressor_bzip2_open(struct archive_write_filter *);
static int archive_compressor_bzip2_options(struct archive_write_filter *,
		    const char *, const char *);
static int archive_compressor_bzip2_write(struct archive_write_filter *,
		    const void *, size_t);
static void free_data(struct bzip2 *);

/*
 * Add a bzip2 compression filter to this write handle.
 */
int
archive_write_add_filter_bzip2(struct archive *a)
{
	struct archive_write_filter *f;
	struct bzip2 *bzip2;
	int r;

	archive_check_magic(a, ARCHIVE_WRITE_MAGIC,
	    ARCHIVE_STATE_NEW, "archive_write_add_filter_bzip2");

	bzip2 = calloc(1, sizeof(*bzip2));
	if (bzip2 == NULL)
		goto memerr;
#if defined(HAVE_BZLIB_H) && defined(BZ_CONFIG_ERROR)
	bzip2->compression_level = 9;

	r = ARCHIVE_OK;
#else
	bzip2->pdata = __archive_write_program_allocate("bzip2");
	if (bzip2->pdata == NULL)
		goto memerr;
	bzip2->compression_level = 0;

	archive_set_error(a, ARCHIVE_ERRNO_MISC,
	    "Using external bzip2 program");
	r = ARCHIVE_WARN;
#endif

	f = __archive_write_allocate_filter(a);
	if (f == NULL)
		goto memerr;
	f->name = "bzip2";
	f->code = ARCHIVE_FILTER_BZIP2;
	f->data = bzip2;
	f->options = archive_compressor_bzip2_options;
	f->open = archive_compressor_bzip2_open;
	f->write = archive_compressor_bzip2_write;
	f->close = archive_compressor_bzip2_close;
	f->free = archive_compressor_bzip2_free;

	return (r);
memerr:
	free_data(bzip2);
	archive_set_error(a, ENOMEM, "Out of memory");
	return (ARCHIVE_FATAL);
}

static int
archive_compressor_bzip2_free(struct archive_write_filter *f)
{
	free_data(f->data);
	f->data = NULL;
	return (ARCHIVE_OK);
}

/*
 * Set write options.
 */
static int
archive_compressor_bzip2_options(struct archive_write_filter *f,
    const char *key, const char *value)
{
	struct bzip2 *bzip2 = f->data;

	if (strcmp(key, "compression-level") == 0) {
		if (value == NULL || !(value[0] >= '0' && value[0] <= '9') ||
		    value[1] != '\0') {
			archive_set_error(f->archive, ARCHIVE_ERRNO_MISC,
			    "compression-level invalid");
			return (ARCHIVE_FAILED);
		}
		bzip2->compression_level = value[0] - '0';
		/* Make '0' be a synonym for '1'. */
		/* This way, bzip2 compressor supports the same 0..9
		 * range of levels as gzip. */
		if (bzip2->compression_level < 1)
			bzip2->compression_level = 1;
		return (ARCHIVE_OK);
	}

	/* Note: The "warn" return is just to inform the options
	 * supervisor that we didn't handle it.  It will generate
	 * a suitable error if no one used this option. */
	return (ARCHIVE_WARN);
}

#if defined(HAVE_BZLIB_H) && defined(BZ_CONFIG_ERROR)
/* Don't compile this if we don't have bzlib. */

/*
 * Yuck.  bzlib.h is not const-correct, so I need this one bit
 * of ugly hackery to convert a const * pointer to a non-const pointer.
 */
#define	SET_NEXT_IN(st,src)					\
	(st)->stream.next_in = (char *)(uintptr_t)(const void *)(src)
static int drive_compressor(struct archive_write_filter *,
		    struct bzip2 *, int finishing);

/*
 * Setup callback.
 */
static int
archive_compressor_bzip2_open(struct archive_write_filter *f)
{
	struct bzip2 *bzip2 = f->data;
	int ret;

	if (bzip2->compressed == NULL) {
		size_t bs = 65536, bpb;
		if (f->archive->magic == ARCHIVE_WRITE_MAGIC) {
			/* Buffer size should be a multiple number of the bytes
			 * per block for performance. */
			bpb = archive_write_get_bytes_per_block(f->archive);
			if (bpb > bs)
				bs = bpb;
			else if (bpb != 0)
				bs -= bs % bpb;
		}
		bzip2->compressed_buffer_size = bs;
		bzip2->compressed = malloc(bzip2->compressed_buffer_size);
		if (bzip2->compressed == NULL) {
			archive_set_error(f->archive, ENOMEM,
			    "Can't allocate data for compression buffer");
			return (ARCHIVE_FATAL);
		}
	}

	memset(&bzip2->stream, 0, sizeof(bzip2->stream));
	bzip2->stream.next_out = bzip2->compressed;
	bzip2->stream.avail_out = (uint32_t)bzip2->compressed_buffer_size;

	/* Initialize compression library */
	ret = BZ2_bzCompressInit(&(bzip2->stream),
	    bzip2->compression_level, 0, 30);
	if (ret == BZ_OK) {
		return (ARCHIVE_OK);
	}

	/* Library setup failed: clean up. */
	archive_set_error(f->archive, ARCHIVE_ERRNO_MISC,
	    "Internal error initializing compression library");

	/* Override the error message if we know what really went wrong. */
	switch (ret) {
	case BZ_PARAM_ERROR:
		archive_set_error(f->archive, ARCHIVE_ERRNO_MISC,
		    "Internal error initializing compression library: "
		    "invalid setup parameter");
		break;
	case BZ_MEM_ERROR:
		archive_set_error(f->archive, ENOMEM,
		    "Internal error initializing compression library: "
		    "out of memory");
		break;
	case BZ_CONFIG_ERROR:
		archive_set_error(f->archive, ARCHIVE_ERRNO_MISC,
		    "Internal error initializing compression library: "
		    "mis-compiled library");
		break;
	}

	return (ARCHIVE_FATAL);

}

/*
 * Write data to the compressed stream.
 *
 * Returns ARCHIVE_OK if all data written, error otherwise.
 */
static int
archive_compressor_bzip2_write(struct archive_write_filter *f,
    const void *buff, size_t length)
{
	struct bzip2 *bzip2 = f->data;

	/* Compress input data to output buffer */
	SET_NEXT_IN(bzip2, buff);
	bzip2->stream.avail_in = (uint32_t)length;
	if (drive_compressor(f, bzip2, 0))
		return (ARCHIVE_FATAL);
	return (ARCHIVE_OK);
}


/*
 * Finish the compression.
 */
static int
archive_compressor_bzip2_close(struct archive_write_filter *f)
{
	struct bzip2 *bzip2 = f->data;
	int ret;

	/* Finish compression cycle. */
	ret = drive_compressor(f, bzip2, 1);
	if (ret == ARCHIVE_OK) {
		/* Write the last block */
		ret = __archive_write_filter(f->next_filter,
		    bzip2->compressed,
		    bzip2->compressed_buffer_size - bzip2->stream.avail_out);
	}

	switch (BZ2_bzCompressEnd(&(bzip2->stream))) {
	case BZ_OK:
		break;
	default:
		archive_set_error(f->archive, ARCHIVE_ERRNO_PROGRAMMER,
		    "Failed to clean up compressor");
		ret = ARCHIVE_FATAL;
	}
	return ret;
}

/*
 * Utility function to push input data through compressor, writing
 * full output blocks as necessary.
 *
 * Note that this handles both the regular write case (finishing ==
 * false) and the end-of-archive case (finishing == true).
 */
static int
drive_compressor(struct archive_write_filter *f,
    struct bzip2 *bzip2, int finishing)
{
	int ret;

	for (;;) {
		if (bzip2->stream.avail_out == 0) {
			ret = __archive_write_filter(f->next_filter,
			    bzip2->compressed,
			    bzip2->compressed_buffer_size);
			if (ret != ARCHIVE_OK) {
				/* TODO: Handle this write failure */
				return (ARCHIVE_FATAL);
			}
			bzip2->stream.next_out = bzip2->compressed;
			bzip2->stream.avail_out = (uint32_t)bzip2->compressed_buffer_size;
		}

		/* If there's nothing to do, we're done. */
		if (!finishing && bzip2->stream.avail_in == 0)
			return (ARCHIVE_OK);

		ret = BZ2_bzCompress(&(bzip2->stream),
		    finishing ? BZ_FINISH : BZ_RUN);

		switch (ret) {
		case BZ_RUN_OK:
			/* In non-finishing case, did compressor
			 * consume everything? */
			if (!finishing && bzip2->stream.avail_in == 0)
				return (ARCHIVE_OK);
			break;
		case BZ_FINISH_OK:  /* Finishing: There's more work to do */
			break;
		case BZ_STREAM_END: /* Finishing: all done */
			/* Only occurs in finishing case */
			return (ARCHIVE_OK);
		default:
			/* Any other return value indicates an error */
			archive_set_error(f->archive,
			    ARCHIVE_ERRNO_PROGRAMMER,
			    "Bzip2 compression failed;"
			    " BZ2_bzCompress() returned %d",
			    ret);
			return (ARCHIVE_FATAL);
		}
	}
}

static void
free_data(struct bzip2 *bzip2)
{
	if (bzip2 != NULL) {
		/* May already have been called, but not necessarily. */
		(void)BZ2_bzCompressEnd(&(bzip2->stream));

		free(bzip2->compressed);
		free(bzip2);
	}
}

#else /* HAVE_BZLIB_H && BZ_CONFIG_ERROR */

static int
archive_compressor_bzip2_open(struct archive_write_filter *f)
{
	struct bzip2 *bzip2 = f->data;
	struct archive_string as;
	int r;

	archive_string_init(&as);
	archive_strcpy(&as, "bzip2");

	/* Specify compression level. */
	if (bzip2->compression_level > 0) {
		archive_strcat(&as, " -");
		archive_strappend_char(&as, '0' + bzip2->compression_level);
	}

	r = __archive_write_program_open(f, bzip2->pdata, as.s);
	archive_string_free(&as);
	return (r);
}

static int
archive_compressor_bzip2_write(struct archive_write_filter *f, const void *buff,
    size_t length)
{
	struct bzip2 *bzip2 = f->data;

	return __archive_write_program_write(f, bzip2->pdata, buff, length);
}

static int
archive_compressor_bzip2_close(struct archive_write_filter *f)
{
	struct bzip2 *bzip2 = f->data;

	return __archive_write_program_close(f, bzip2->pdata);
}

static void
free_data(struct bzip2 *bzip2)
{
	if (bzip2 != NULL) {
		__archive_write_program_free(bzip2->pdata);
		free(bzip2);
	}
}

#endif /* HAVE_BZLIB_H && BZ_CONFIG_ERROR */
